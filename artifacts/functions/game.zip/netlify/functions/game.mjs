
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/game.ts
import { getStore } from "@netlify/blobs";

// lib/game-service.mjs
import { createHash as createHash2, randomInt as randomInt2 } from "node:crypto";

// engine.mjs
import { randomBytes, randomInt, createHash } from "node:crypto";

// decks.json
var decks_default = [
  {
    id: "general",
    title: "General & Absurd",
    description: "Tiny choices. Enormous opinions. Absolutely no sensible answers.",
    questions: [
      { id: "general-01", prompt: "You get one mildly inconvenient superpower. What are you choosing?", a: "Fly, but only walking speed", b: "Teleport, but arrive damp" },
      { id: "general-02", prompt: "Every time you enter a room, which sound should follow you?", a: "A dramatic movie soundtrack", b: "A tiny round of applause" },
      { id: "general-03", prompt: "Your pet can talk for one minute. What would you rather hear?", a: "Their honest review of you", b: "Their biggest secret" },
      { id: "general-04", prompt: "You must wear one accessory every day for a year. Which one?", a: "A magnificent wizard hat", b: "A tiny superhero cape" },
      { id: "general-05", prompt: "Which daily inconvenience would you permanently erase?", a: "Waiting in lines", b: "Forgetting why you entered a room" },
      { id: "general-06", prompt: "Aliens arrive and ask you to explain one human habit. Pick your challenge.", a: "Small talk about the weather", b: "Clapping when a plane lands" },
      { id: "general-07", prompt: "Your fridge gains one magical feature. What should it do?", a: "Refill your favorite snack", b: "Cook whatever is already inside" },
      { id: "general-08", prompt: "Which would make an ordinary Tuesday more interesting?", a: "Everyone wears roller skates", b: "Everyone speaks in song lyrics" },
      { id: "general-09", prompt: "You can always find one thing instantly. What are you picking?", a: "The perfect parking spot", b: "The thing you just lost" },
      { id: "general-10", prompt: "A harmless goose has decided to follow you everywhere. What do you do?", a: "Give it a name and a bow tie", b: "Hire it as my personal security" },
      { id: "general-11", prompt: "You must eat breakfast for one other meal forever. When is it happening?", a: "Breakfast for lunch", b: "Breakfast for dinner" },
      { id: "general-12", prompt: "A genie upgrades your home with one completely unnecessary room. Choose.", a: "A room full of trampolines", b: "A room full of friendly puppies" },
      { id: "general-13", prompt: "You have to compete in a ridiculous championship. What's your event?", a: "Competitive napping", b: "Speed assembling flat-pack furniture" },
      { id: "general-14", prompt: "Which tiny luxury deserves a lifetime subscription?", a: "Fresh sheets every night", b: "A perfect drink every morning" },
      { id: "general-15", prompt: "Your reflection starts offering advice. Which kind do you want?", a: "Unfiltered fashion feedback", b: "Wildly enthusiastic pep talks" },
      { id: "general-16", prompt: "You can swap one chore for a five-minute dance battle. Which chore goes?", a: "Washing dishes", b: "Folding laundry" },
      { id: "general-17", prompt: "Which harmless curse would be easier to live with?", a: "Squeaky shoes forever", b: "Hiccups whenever you say hello" },
      { id: "general-18", prompt: "You discover a secret door in your house. Where should it lead?", a: "A quiet beach at sunset", b: "A diner where everything is free" },
      { id: "general-19", prompt: "You can pause time for ten minutes daily. How are you using it?", a: "Get a little extra sleep", b: "Think of the perfect comeback" },
      { id: "general-20", prompt: "The world replaces handshakes with a new greeting. What gets your vote?", a: "Finger guns and a wink", b: "A deeply serious little bow" }
    ]
  },
  {
    id: "pop",
    title: "Pop Culture & Movies",
    description: "Main character energy, questionable sequels, and popcorn arguments.",
    questions: [
      { id: "pop-01", prompt: "You get dropped into a movie universe for a week. Which kind?", a: "A cozy romantic comedy", b: "An epic space adventure" },
      { id: "pop-02", prompt: "Your favorite show gets one more season. Who should take the lead?", a: "The beloved side character", b: "A completely new character" },
      { id: "pop-03", prompt: "The perfect movie night has one nonnegotiable rule. Which one?", a: "Absolutely no talking", b: "Live commentary is encouraged" },
      { id: "pop-04", prompt: "You can instantly master one entertainment talent. What do you pick?", a: "Sing any song beautifully", b: "Do a flawless celebrity impression" },
      { id: "pop-05", prompt: "A movie is being made about your life. How should it be told?", a: "An over-the-top action movie", b: "A lovingly awkward comedy" },
      { id: "pop-06", prompt: "You must choose your streaming fate for a year. Which is worse?", a: "Only rewatch things you've seen", b: "Never finish a series you start" },
      { id: "pop-07", prompt: "Which fictional job would you try for a day?", a: "A superhero's personal assistant", b: "A fantasy kingdom's royal chef" },
      { id: "pop-08", prompt: "A beloved classic is getting remade. What's your preference?", a: "Keep the original story intact", b: "Take it somewhere totally new" },
      { id: "pop-09", prompt: "You can bring one movie feature into everyday life. Choose wisely.", a: "A soundtrack only you can hear", b: "Montages that finish your chores" },
      { id: "pop-10", prompt: "Your concert ticket includes one extra perk. What do you want?", a: "Front row for the whole show", b: "A relaxed chat with the artist" },
      { id: "pop-11", prompt: "Your group can agree on only one movie genre tonight. Which wins?", a: "A mystery with a huge twist", b: "A comedy everyone can quote" },
      { id: "pop-12", prompt: "You win a role in a blockbuster. Which role sounds more fun?", a: "The dramatically stylish villain", b: "The scene-stealing best friend" },
      { id: "pop-13", prompt: "A song gets stuck in your head for a month. Which song should it be?", a: "Your all-time favorite", b: "A catchy song you barely know" },
      { id: "pop-14", prompt: "What makes a better ending to a long-running series?", a: "Every loose end tied up", b: "One bold, unforgettable surprise" },
      { id: "pop-15", prompt: "You get one fictional item, but it works only once. What do you take?", a: "A time machine", b: "A magic wand" },
      { id: "pop-16", prompt: "Your favorite actor is sitting next to you on a flight. What's your move?", a: "Politely say hello once", b: "Pretend you have no idea" },
      { id: "pop-17", prompt: "You must enter a television competition. Which gives you a better shot?", a: "An amateur cooking show", b: "A ridiculous obstacle course" },
      { id: "pop-18", prompt: "A new release is three hours long. What's the ideal way to watch?", a: "One uninterrupted cinema trip", b: "At home with an intermission" },
      { id: "pop-19", prompt: "Your life suddenly includes a narrator. What tone should they have?", a: "An excited sports commentator", b: "A soothing nature documentarian" },
      { id: "pop-20", prompt: "Which entertainment time capsule would you open first?", a: "Your childhood favorite movies", b: "Your old music playlists" }
    ]
  },
  {
    id: "dating",
    title: "Dating & Social Dilemmas",
    description: "Group chats, first dates, and the tiny decisions that become a whole thing.",
    questions: [
      { id: "dating-01", prompt: "Which first date gives you a better chance to connect?", a: "Coffee and a long walk", b: "Mini golf and friendly trash talk" },
      { id: "dating-02", prompt: "Your friend asks if their terrible haircut looks good. What do you say?", a: "Be gently honest", b: "Find one thing to compliment" },
      { id: "dating-03", prompt: "The group chat has been planning dinner for six days. What's your move?", a: "Pick a place and book it", b: "Send a poll and hope for peace" },
      { id: "dating-04", prompt: "You're early to a party where you know only the host. What do you do?", a: "Help set up and meet everyone", b: "Take a quick walk and return later" },
      { id: "dating-05", prompt: "Which texting habit is more frustrating?", a: "Replies that take three days", b: "Ten messages for one sentence" },
      { id: "dating-06", prompt: "A friend spoils the show you're watching. What is fair payback?", a: "They owe you your favorite snack", b: "You choose the next movie night" },
      { id: "dating-07", prompt: "Your date orders something much better than you did. What's acceptable?", a: "Ask for a bite", b: "Order your own second dish" },
      { id: "dating-08", prompt: "Which invitation sounds more appealing on a free Saturday?", a: "A spontaneous road trip", b: "A carefully planned night in" },
      { id: "dating-09", prompt: "Someone waves in your direction, but you aren't sure it's for you. React!", a: "Wave confidently anyway", b: "Turn around to check first" },
      { id: "dating-10", prompt: "Your friend always runs twenty minutes late. How do you handle it?", a: "Give them an earlier start time", b: "Start without them, no hard feelings" },
      { id: "dating-11", prompt: "What's a stronger sign of a great friendship?", a: "You can talk for hours", b: "You can be silent without awkwardness" },
      { id: "dating-12", prompt: "Your partner plans a surprise outing. Which surprise would you prefer?", a: "Fancy dinner with a dress code", b: "A goofy adventure in comfy clothes" },
      { id: "dating-13", prompt: "A stranger gives you a sincere compliment. How do you usually respond?", a: "Accept it with a simple thank you", b: "Immediately compliment them back" },
      { id: "dating-14", prompt: "You realize you've called someone the wrong name for weeks. Now what?", a: "Own it and apologize", b: "Ask a mutual friend to clarify it" },
      { id: "dating-15", prompt: "Your friend wants to post a group photo where you look ridiculous. Decide.", a: "Post it; the memory matters", b: "Retake it; everyone deserves a win" },
      { id: "dating-16", prompt: "Which guest is more welcome at your dinner party?", a: "The great storyteller", b: "The person who does the dishes" },
      { id: "dating-17", prompt: "You can share one hobby with a future partner. What would it be?", a: "Cooking adventurous meals", b: "Exploring new places" },
      { id: "dating-18", prompt: "You accidentally send a silly selfie to the wrong group chat. Your response?", a: "Own it with an even sillier caption", b: "Explain, apologize, and move on" },
      { id: "dating-19", prompt: "Your friends want matching outfits on vacation. Where do you stand?", a: "I'm in; commit to the bit", b: "One matching accessory is plenty" },
      { id: "dating-20", prompt: "Which is the better way to celebrate a friend's big achievement?", a: "A surprise party with everyone", b: "A thoughtful one-on-one outing" }
    ]
  },
  {
    id: "work",
    title: "Workplace & School Shenanigans",
    description: "Meetings, group projects, and heroic levels of procrastination.",
    questions: [
      { id: "work-01", prompt: "Your next meeting or class gets one magical improvement. Pick it.", a: "It always ends ten minutes early", b: "It always includes excellent snacks" },
      { id: "work-02", prompt: "A group project needs a volunteer. Which role are you taking?", a: "Present the final result", b: "Make the slides look amazing" },
      { id: "work-03", prompt: "You can change your daily schedule permanently. What sounds better?", a: "Start early and finish early", b: "Start late and finish late" },
      { id: "work-04", prompt: "Which would improve a long work or school day more?", a: "A quiet room for a quick nap", b: "A free cafe with your favorite drink" },
      { id: "work-05", prompt: "Someone says, 'Let's do a fun icebreaker.' Which do you choose?", a: "Two truths and a lie", b: "Show a photo of your pet" },
      { id: "work-06", prompt: "Your camera turns on unexpectedly during a video call. What's worse?", a: "You're wearing a ridiculous hat", b: "You're dramatically singing along" },
      { id: "work-07", prompt: "A deadline is a week away. What's your natural approach?", a: "Finish early and relax", b: "Let the deadline unlock my powers" },
      { id: "work-08", prompt: "You can remove one phrase from all meetings forever. Which one?", a: "Let's circle back", b: "Can everyone see my screen?" },
      { id: "work-09", prompt: "Which desk neighbor would you rather have?", a: "The constant snack sharer", b: "The person with every spare charger" },
      { id: "work-10", prompt: "You get a surprise free hour in your day. How do you spend it?", a: "Get ahead on tomorrow's tasks", b: "Take a glorious actual break" },
      { id: "work-11", prompt: "You must use one unusual presentation style. Which will you commit to?", a: "Explain everything with sock puppets", b: "Deliver it like a weather forecast" },
      { id: "work-12", prompt: "Which reward would make a difficult project feel more worthwhile?", a: "Public praise from the whole team", b: "A quiet thank you and a day off" },
      { id: "work-13", prompt: "The office or classroom can have one new pet. Cast your vote.", a: "A very chill rescue dog", b: "An aquarium with dramatic fish" },
      { id: "work-14", prompt: "Your group can't agree on a team name. Which direction wins?", a: "A truly terrible pun", b: "Something unnecessarily intimidating" },
      { id: "work-15", prompt: "Which skill would you rather have during a busy week?", a: "Never lose focus", b: "Always know exactly what to say" },
      { id: "work-16", prompt: "An email marked urgent arrives just as you're leaving. What's your instinct?", a: "Check if it really needs me now", b: "Save it for tomorrow morning" },
      { id: "work-17", prompt: "Everyone must join a friendly talent show. What's your act?", a: "A wildly committed karaoke song", b: "A suspiciously simple magic trick" },
      { id: "work-18", prompt: "You can redesign your workspace with one ridiculous upgrade. Choose.", a: "A slide instead of the stairs", b: "A chair that gives perfect massages" },
      { id: "work-19", prompt: "Which teammate would you recruit for a stressful challenge?", a: "The calm, organized planner", b: "The fearless improviser" },
      { id: "work-20", prompt: "You discover a shortcut that saves everyone an hour. What do you do first?", a: "Share it immediately", b: "Test it carefully before sharing" }
    ]
  },
  {
    id: "holiday",
    title: "Holiday Chaos",
    description: "Festive traditions, family plot twists, and very strong dessert opinions.",
    questions: [
      { id: "holiday-01", prompt: "Your Halloween costume must take one extreme. Which one?", a: "Terrifyingly realistic", b: "A delightfully terrible pun" },
      { id: "holiday-02", prompt: "You may claim one extra helping at a holiday feast. What gets the space?", a: "The savory side dishes", b: "The dessert table" },
      { id: "holiday-03", prompt: "A winter getaway needs one main feature. Which do you choose?", a: "Snow, blankets, and a fireplace", b: "Sunshine and absolutely no coats" },
      { id: "holiday-04", prompt: "You're in charge of the spring egg hunt. What's your style?", a: "Easy hiding spots and lots of candy", b: "Riddles, clues, and a grand prize" },
      { id: "holiday-05", prompt: "Someone gives you a gift you already own. What is your first move?", a: "Thank them and keep it quiet", b: "Gently ask about an exchange" },
      { id: "holiday-06", prompt: "Which holiday tradition deserves to last all year?", a: "Putting lights on everything", b: "Having an excuse to bake cookies" },
      { id: "holiday-07", prompt: "You must join one festive contest. Which one gives you a chance?", a: "Pumpkin carving", b: "Gingerbread house construction" },
      { id: "holiday-08", prompt: "The family holiday photo is going badly. What saves it?", a: "One completely silly pose", b: "Bribing everyone with dessert" },
      { id: "holiday-09", prompt: "You can attend only one New Year's celebration. Where are you going?", a: "A huge party and midnight countdown", b: "A cozy dinner with favorite people" },
      { id: "holiday-10", prompt: "A holiday meal can have only one sweet centerpiece. Your vote?", a: "A spectacular homemade pie", b: "A giant assortment of cookies" },
      { id: "holiday-11", prompt: "Which gift would you rather receive from a friend?", a: "A thoughtful handmade creation", b: "Tickets to do something together" },
      { id: "holiday-12", prompt: "You are decorating for a party. Which approach wins?", a: "Elegant and perfectly coordinated", b: "Every decoration we own, everywhere" },
      { id: "holiday-13", prompt: "Which Halloween activity sounds more fun with this group?", a: "A spooky haunted house", b: "A scary movie with lots of snacks" },
      { id: "holiday-14", prompt: "You can magically skip one holiday task. What disappears?", a: "Wrapping every present", b: "Cleaning up after the big meal" },
      { id: "holiday-15", prompt: "Your holiday playlist needs a rule. What should it be?", a: "Only the classics everyone knows", b: "Fresh songs and unexpected covers" },
      { id: "holiday-16", prompt: "A surprise snow day cancels all your plans. What happens next?", a: "Build something ridiculous outside", b: "Become one with the couch" },
      { id: "holiday-17", prompt: "Your costume looks nothing like you planned. What's the solution?", a: "Invent a convincing backstory", b: "Turn it into a ghost with a sheet" },
      { id: "holiday-18", prompt: "Which seasonal treat should be available every single month?", a: "Pumpkin spice everything", b: "Peppermint and chocolate everything" },
      { id: "holiday-19", prompt: "You host a spring picnic, but rain is coming. What's the backup plan?", a: "Move the picnic to the living room", b: "Grab raincoats and embrace it" },
      { id: "holiday-20", prompt: "The holidays are over. When should the decorations come down?", a: "Promptly; I'm ready for a reset", b: "Whenever the festive mood fades" }
    ]
  }
];

// config.mjs
var COLORS = [
  ["lime", "Lime", "#c2f653", "#203000"],
  ["violet", "Violet", "#b9a1ff", "#27164f"],
  ["coral", "Coral", "#ff837c", "#4e1717"],
  ["sky", "Sky", "#70c5ff", "#102d48"],
  ["yellow", "Yellow", "#ffe16d", "#403500"],
  ["pink", "Pink", "#f892cf", "#4f133d"],
  ["mint", "Mint", "#7bdeb4", "#133c2c"],
  ["orange", "Orange", "#ffad4a", "#472500"],
  ["lilac", "Lilac", "#dcc6ff", "#3d2858"],
  ["teal", "Teal", "#2bb9a8", "#062e29"],
  ["red", "Red", "#dd4556", "#fff"],
  ["blue", "Blue", "#476beb", "#fff"],
  ["purple", "Purple", "#814ace", "#fff"],
  ["forest", "Forest", "#397c4f", "#fff"],
  ["rust", "Rust", "#b85c36", "#fff"],
  ["gold", "Gold", "#b29a32", "#171402"],
  ["rose", "Rose", "#ba5080", "#fff"],
  ["slate", "Slate", "#7797aa", "#12202b"],
  ["cream", "Cream", "#f1e4c4", "#443b26"],
  ["silver", "Silver", "#b8bfcc", "#28303d"]
].map(([id, name, hex, ink]) => ({ id, name, hex, ink }));
var THEMES = [
  { id: "standard", title: "Standard", short: "Standard", colors: ["#c2f653", "#b9a1ff"] },
  { id: "halloween", title: "Halloween", short: "Halloween", colors: ["#ffad4a", "#904fcc"] },
  { id: "thanksgiving", title: "Thanksgiving", short: "Autumn", colors: ["#efbd64", "#b85c36"] },
  { id: "winter", title: "Christmas / Winter", short: "Winter", colors: ["#397c4f", "#ff7d86"] },
  { id: "spring", title: "Easter / Spring", short: "Spring", colors: ["#b8dfc6", "#d7c9f1"] }
];

// engine.mjs
var DECKS = decks_default;
var MAX_DECKS = 50;
var GameError = class extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
};
var need = (condition, message, status = 400) => {
  if (!condition) throw new GameError(message, status);
};
var tidy = (value) => typeof value === "string" ? value.normalize("NFKC").trim().replace(/\s+/gu, " ") : "";
var normalized = (value) => tidy(value).toLocaleLowerCase("en-US");
var fingerprint = (q) => createHash("sha256").update(JSON.stringify([normalized(q.prompt), ...[normalized(q.a), normalized(q.b)].sort()])).digest("hex");
function validateQuestion(value) {
  need(value && typeof value === "object", "Please enter a question and two choices.");
  const q = { prompt: tidy(value.prompt), a: tidy(value.a), b: tidy(value.b) };
  need(q.prompt.length >= 15 && q.prompt.length <= 120, "The prompt must be 15\u2013120 characters.");
  need([q.a, q.b].every((v) => v.length >= 2 && v.length <= 40), "Each choice must be 2\u201340 characters.");
  need(normalized(q.a) !== normalized(q.b), "The two choices must be different.");
  need(!/[\u0000-\u001f\u007f]/u.test(q.prompt + q.a + q.b), "Please use readable text.");
  return q;
}
function exportDeck(questions) {
  return "MR1." + Buffer.from(JSON.stringify(questions.map((q) => [q.prompt, q.a, q.b])), "utf8").toString("base64url");
}
function importDeck(value) {
  need(typeof value === "string" && value.trim().length <= 8e4, "That deck code is too large.");
  const code = value.trim();
  need(/^MR1\.[A-Za-z0-9_-]+$/u.test(code), "Use a valid MR1 deck code.");
  let rows;
  try {
    const bytes = Buffer.from(code.slice(4), "base64url");
    need(bytes.toString("base64url") === code.slice(4), "That deck code is malformed.");
    rows = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new GameError("That deck code is damaged or invalid.");
  }
  need(Array.isArray(rows) && rows.length >= 1 && rows.length <= 100, "A deck code must contain 1\u2013100 questions.");
  return rows.map((row) => {
    need(Array.isArray(row) && row.length === 3, "That deck contains an invalid question.");
    return validateQuestion({ prompt: row[0], a: row[1], b: row[2] });
  });
}
need(DECKS.length > 0 && DECKS.length <= MAX_DECKS, "The deck catalog must contain 1\u201350 decks.");
need(new Set(DECKS.map((d) => d.id)).size === DECKS.length, "Deck identifiers must be unique.");
for (const deck of DECKS) {
  need(deck.questions.length >= 20, "Each deck must contain at least 20 questions.");
  deck.questions.forEach(validateQuestion);
}
var shuffle = (list) => {
  const result = [...list];
  for (let i = result.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
};
var scoreFor = (streak) => streak >= 4 ? 200 : streak === 3 ? 150 : streak === 2 ? 125 : 100;
var GameEngine = class {
  constructor({ now = () => Date.now(), onChange = () => {
  } } = {}) {
    this.rooms = /* @__PURE__ */ new Map();
    this.now = now;
    this.onChange = onChange;
  }
  active(room) {
    return [...room.players.values()].filter((p) => p.connected);
  }
  emit(room) {
    room.updatedAt = this.now();
    room.revision++;
    this.onChange(room);
  }
  get(code) {
    const room = this.rooms.get(tidy(code).toUpperCase());
    need(room, "Room not found. Check the six-character code.", 404);
    return room;
  }
  player(room, token) {
    const p = [...room.players.values()].find((p2) => p2.token === token);
    need(p, "Your seat has expired. Please join again.", 401);
    return p;
  }
  host(room, p) {
    need(room.hostId === p.id, "Only the host can do that.", 403);
  }
  lobby(room) {
    need(room.phase === "lobby", "This is available in the lobby between games.", 409);
  }
  create({ nickname, color }) {
    need(this.rooms.size < 500, "The party server is full. Try again later.", 503);
    let code;
    do {
      code = randomBytes(6).reduce((s, n) => s + "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[n % 31], "");
    } while (this.rooms.has(code));
    const room = { code, revision: 0, createdAt: this.now(), updatedAt: this.now(), hostId: null, phase: "lobby", players: /* @__PURE__ */ new Map(), settings: { theme: "standard", deck: "general", rounds: 5 }, custom: [], rejected: /* @__PURE__ */ new Set(), queue: [], ballot: null, history: [], round: null, roundIndex: 0, questions: [], matchId: 0 };
    const p = this.addPlayer(room, { nickname, color });
    room.hostId = p.id;
    this.rooms.set(code, room);
    this.emit(room);
    return { room, p };
  }
  addPlayer(room, { nickname, color }) {
    need(room.players.size < 8, "This room already has eight players. The host can release offline seats.", 409);
    const name = tidy(nickname);
    need(name.length >= 1 && name.length <= 20, "Use a nickname of 1\u201320 characters.");
    need(!/[\u0000-\u001f\u007f]/u.test(name), "Please use a readable nickname.");
    need(COLORS.some((c) => c.id === color), "Choose an avatar color.");
    need(![...room.players.values()].some((p2) => p2.color === color), "That color was just taken. Choose another.", 409);
    const p = { id: randomBytes(9).toString("hex"), token: randomBytes(32).toString("hex"), nickname: name, color, score: 0, streak: 0, bestStreak: 0, connected: true, joinedAt: this.now(), lastSeen: this.now(), offlineAt: null };
    room.players.set(p.id, p);
    return p;
  }
  join(code, details) {
    const room = this.get(code);
    need(["lobby", "podium"].includes(room.phase), "This game has started. Join when the group returns to the lobby.", 409);
    const p = this.addPlayer(room, details);
    this.evaluateBallot(room);
    this.emit(room);
    return { room, p };
  }
  connect(room, p) {
    p.connected = true;
    p.lastSeen = this.now();
    p.offlineAt = null;
    if (!room.hostId || !room.players.get(room.hostId)?.connected) room.hostId = p.id;
    this.evaluateBallot(room);
    this.emit(room);
  }
  disconnect(room, p) {
    if (!room.players.has(p.id) || !p.connected) return;
    p.connected = false;
    p.offlineAt = this.now();
    this.migrateHost(room);
    this.evaluateBallot(room);
    this.maybeReveal(room);
    this.emit(room);
  }
  migrateHost(room) {
    if (!room.players.get(room.hostId)?.connected) room.hostId = this.active(room)[0]?.id ?? room.hostId;
  }
  leave(room, p) {
    room.players.delete(p.id);
    if (room.hostId === p.id) room.hostId = null;
    this.migrateHost(room);
    this.evaluateBallot(room);
    this.maybeReveal(room);
    this.emit(room);
  }
  publicInfo(room) {
    return { code: room.code, phase: room.phase, playerCount: room.players.size, takenColors: [...room.players.values()].map((p) => p.color), joinable: ["lobby", "podium"].includes(room.phase) && room.players.size < 8 };
  }
  settings(room, p, changes) {
    this.host(room, p);
    this.lobby(room);
    need(changes && typeof changes === "object", "Choose valid settings.");
    const next = { ...room.settings };
    if (changes.theme !== void 0) {
      need(THEMES.some((t) => t.id === changes.theme), "Unknown theme.");
      next.theme = changes.theme;
    }
    if (changes.deck !== void 0) {
      need(DECKS.some((d) => d.id === changes.deck), "Unknown deck.");
      next.deck = changes.deck;
    }
    if (changes.rounds !== void 0) {
      need([3, 5, 10, 15, 20].includes(changes.rounds), "Choose 3, 5, 10, 15, or 20 rounds.");
      next.rounds = changes.rounds;
    }
    room.settings = next;
    this.emit(room);
  }
  known(room, key) {
    return room.custom.some((q) => q.key === key) || room.ballot?.question.key === key || room.queue.some((q) => q.key === key);
  }
  submit(room, p, value) {
    this.lobby(room);
    const q = validateQuestion(value);
    const key = fingerprint(q);
    need(!room.rejected.has(key), "That question was rejected and is locked for this room session.", 409);
    need(!this.known(room, key), "That question is already in this room.", 409);
    need(room.custom.length + room.queue.length + (room.ballot ? 1 : 0) < 100, "This room can hold up to 100 custom questions.");
    room.queue.push({ ...q, key, id: randomBytes(8).toString("hex"), authorId: p.id, author: p.nickname });
    this.nextBallot(room);
    this.emit(room);
  }
  nextBallot(room) {
    if (room.ballot || !room.queue.length) return;
    const question = room.queue.shift();
    room.ballot = { id: randomBytes(8).toString("hex"), question, votes: { [question.authorId]: true }, deadline: this.now() + 2e4 };
    this.evaluateBallot(room);
  }
  evaluateBallot(room) {
    const ballot = room.ballot;
    if (!ballot) return;
    if (this.now() >= ballot.deadline) {
      this.finishBallot(room, false);
      return;
    }
    const active = this.active(room);
    const threshold = Math.ceil(active.length * 2 / 3);
    const yes = active.filter((p) => ballot.votes[p.id] === true).length;
    const no = active.filter((p) => ballot.votes[p.id] === false).length;
    if (active.length && yes >= threshold) this.finishBallot(room, true);
    else if (active.length && active.length - no < threshold || this.now() >= ballot.deadline) this.finishBallot(room, false);
  }
  finishBallot(room, approved) {
    const b = room.ballot;
    if (!b) return;
    if (approved) room.custom.push(b.question);
    else room.rejected.add(b.question.key);
    room.history.unshift({ id: b.id, prompt: b.question.prompt, approved });
    room.history = room.history.slice(0, 8);
    room.ballot = null;
    this.nextBallot(room);
  }
  approve(room, p, { id, approve }) {
    this.lobby(room);
    need(room.ballot?.id === id, "That ballot has finished.", 409);
    if (this.now() >= room.ballot.deadline) {
      this.finishBallot(room, false);
      this.emit(room);
      throw new GameError("That approval ballot has expired.", 409);
    }
    need(typeof approve === "boolean", "Choose approve or pass.");
    need(p.connected, "Reconnect before voting.");
    need(room.ballot.votes[p.id] === void 0, "Your approval vote is already locked.", 409);
    room.ballot.votes[p.id] = approve;
    this.evaluateBallot(room);
    this.emit(room);
  }
  import(room, p, code) {
    this.host(room, p);
    this.lobby(room);
    const questions = importDeck(code);
    const additions = [];
    const seen = /* @__PURE__ */ new Set();
    let skipped = 0;
    for (const q of questions) {
      const key = fingerprint(q);
      if (room.rejected.has(key) || this.known(room, key) || seen.has(key)) {
        skipped++;
        continue;
      }
      seen.add(key);
      additions.push({ ...q, key, id: randomBytes(8).toString("hex"), authorId: p.id, author: p.nickname });
    }
    need(room.custom.length + room.queue.length + (room.ballot ? 1 : 0) + additions.length <= 100, "Import would exceed the 100 custom-question limit.");
    room.queue.push(...additions);
    this.nextBallot(room);
    this.emit(room);
    return { added: additions.length, skipped };
  }
  start(room, p) {
    this.host(room, p);
    this.lobby(room);
    need(this.active(room).length >= 2, "At least two connected players are needed to start.");
    need(!room.ballot && !room.queue.length, "Finish the custom-question ballots before starting.");
    const deck = DECKS.find((d) => d.id === room.settings.deck);
    const seen = /* @__PURE__ */ new Set();
    room.questions = [...shuffle(room.custom), ...shuffle(deck.questions)].filter((q) => {
      const key = fingerprint(q);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, room.settings.rounds);
    need(room.questions.length >= room.settings.rounds, "There are not enough distinct questions.");
    for (const player of room.players.values()) {
      player.score = 0;
      player.streak = 0;
      player.bestStreak = 0;
    }
    room.roundIndex = 0;
    room.matchId++;
    this.startRound(room);
    this.emit(room);
  }
  startRound(room) {
    room.roundIndex++;
    const index = room.roundIndex;
    const blitz = index % 4 === 0;
    room.phase = "voting";
    room.round = { id: randomBytes(9).toString("hex"), question: room.questions[index - 1], blitz, multiplier: index % 5 === 0 ? 2 : 1, duration: blitz ? 8e3 : 2e4, deadline: this.now() + (blitz ? 8e3 : 2e4), eligible: this.active(room).map((p) => p.id), votes: {}, result: null };
  }
  vote(room, p, { id, choice }) {
    need(room.phase === "voting" && room.round?.id === id, "This round has already closed.", 409);
    if (this.now() >= room.round.deadline) {
      this.reveal(room);
      this.emit(room);
      throw new GameError("Time is up. Your vote did not arrive in time.", 409);
    }
    need(room.round.eligible.includes(p.id) && p.connected, "You can vote in the next round.", 403);
    need(choice === "a" || choice === "b", "Choose A or B.");
    need(!room.round.votes[p.id], "Your vote is already locked.", 409);
    room.round.votes[p.id] = choice;
    this.maybeReveal(room);
    this.emit(room);
  }
  maybeReveal(room) {
    if (room.phase !== "voting") return;
    const active = this.active(room).filter((p) => room.round.eligible.includes(p.id));
    if (active.length && active.every((p) => room.round.votes[p.id])) this.reveal(room);
  }
  reveal(room) {
    if (room.phase !== "voting") return;
    const round = room.round;
    const counts = { a: 0, b: 0 };
    Object.values(round.votes).forEach((v) => counts[v]++);
    const winner = counts.a === counts.b ? null : counts.a > counts.b ? "a" : "b";
    const awards = {};
    for (const p of room.players.values()) {
      const win = winner && round.votes[p.id] === winner;
      p.streak = win ? p.streak + 1 : 0;
      p.bestStreak = Math.max(p.bestStreak, p.streak);
      const points = win ? scoreFor(p.streak) * round.multiplier : 0;
      p.score += points;
      awards[p.id] = points;
    }
    round.result = { counts, winner, awards, total: counts.a + counts.b };
    room.phase = "reveal";
  }
  next(room, p) {
    this.host(room, p);
    need(room.phase === "reveal", "Wait until the round is revealed.", 409);
    if (room.roundIndex >= room.settings.rounds) room.phase = "podium";
    else {
      need(this.active(room).length >= 2, "Wait for at least two players to reconnect.");
      this.startRound(room);
    }
    this.emit(room);
  }
  replay(room, p) {
    this.host(room, p);
    need(room.phase === "podium", "Finish the game before playing again.", 409);
    room.phase = "lobby";
    room.round = null;
    room.roundIndex = 0;
    room.questions = [];
    for (const player of room.players.values()) {
      player.score = 0;
      player.streak = 0;
      player.bestStreak = 0;
    }
    this.emit(room);
  }
  action(room, p, action, data = {}) {
    p.lastSeen = this.now();
    switch (action) {
      case "settings":
        return this.settings(room, p, data);
      case "submit":
        return this.submit(room, p, data);
      case "approve":
        return this.approve(room, p, data);
      case "import":
        return this.import(room, p, data.code);
      case "export":
        return { code: exportDeck(room.custom) };
      case "start":
        return this.start(room, p);
      case "vote":
        return this.vote(room, p, data);
      case "next":
        return this.next(room, p);
      case "replay":
        return this.replay(room, p);
      case "leave":
        return this.leave(room, p);
      case "remove": {
        this.host(room, p);
        need(["lobby", "podium"].includes(room.phase), "Release seats between games.");
        const target = room.players.get(data.id);
        need(target && !target.connected, "Only offline seats can be released.");
        return this.leave(room, target);
      }
      default:
        throw new GameError("Unknown action.", 404);
    }
  }
  snapshot(room, viewer) {
    const active = this.active(room);
    const round = room.round;
    const revealed = room.phase === "reveal" || room.phase === "podium";
    const ballot = room.ballot;
    return {
      code: room.code,
      revision: room.revision,
      phase: room.phase,
      hostId: room.hostId,
      you: viewer.id,
      settings: room.settings,
      serverNow: this.now(),
      roundIndex: room.roundIndex,
      matchId: room.matchId,
      players: [...room.players.values()].map((p) => ({ id: p.id, nickname: p.nickname, color: p.color, score: p.score, streak: p.streak, bestStreak: p.bestStreak, connected: p.connected, hasVoted: !!round?.votes[p.id] })),
      custom: room.custom.map(({ id, prompt, a, b, author }) => ({ id, prompt, a, b, author })),
      queuedCount: room.queue.length,
      history: room.history,
      ballot: ballot ? { id: ballot.id, question: { prompt: ballot.question.prompt, a: ballot.question.a, b: ballot.question.b, author: ballot.question.author }, deadline: ballot.deadline, required: Math.ceil(active.length * 2 / 3), activeCount: active.length, yes: active.filter((p) => ballot.votes[p.id] === true).length, no: active.filter((p) => ballot.votes[p.id] === false).length, myVote: ballot.votes[viewer.id] ?? null } : null,
      round: round ? { id: round.id, question: { prompt: round.question.prompt, a: round.question.a, b: round.question.b, custom: !!round.question.author }, blitz: round.blitz, multiplier: round.multiplier, duration: round.duration, deadline: round.deadline, myVote: round.votes[viewer.id] ?? null, eligible: round.eligible.includes(viewer.id), votedCount: Object.keys(round.votes).length, activeCount: active.filter((p) => round.eligible.includes(p.id)).length, ...revealed ? { votes: round.votes, result: round.result } : {} } : null
    };
  }
  tick() {
    for (const room of this.rooms.values()) {
      let changed = false;
      if (room.phase === "voting" && this.now() >= room.round.deadline) {
        this.reveal(room);
        changed = true;
      }
      if (room.ballot && this.now() >= room.ballot.deadline) {
        this.evaluateBallot(room);
        changed = true;
      }
      if (changed) this.emit(room);
      if (!this.active(room).length && this.now() - room.updatedAt > 6 * 60 * 60 * 1e3) this.rooms.delete(room.code);
    }
  }
};

// lib/room-storage.mjs
var ROOM_SCHEMA = 1;
function encodeRoom(room) {
  return {
    ...room,
    schemaVersion: ROOM_SCHEMA,
    players: [...room.players.values()],
    rejected: [...room.rejected]
  };
}
function decodeRoom(value) {
  if (!value || value.schemaVersion !== ROOM_SCHEMA || !Array.isArray(value.players) || !Array.isArray(value.rejected)) {
    throw new Error("Unsupported room record.");
  }
  return {
    ...value,
    players: new Map(value.players.map((player) => [player.id, player])),
    rejected: new Set(value.rejected)
  };
}
var roomKey = (code) => `rooms/${code}`;

// lib/game-service.mjs
var HEARTBEAT_WRITE_MS = 2e3;
var OFFLINE_AFTER_MS = 12e3;
var ROOM_IDLE_TTL_MS = 6 * 60 * 60 * 1e3;
var MAX_ATTEMPTS = 12;
var MAX_RECEIPTS = 2048;
var hash = (value) => createHash2("sha256").update(value).digest("hex");
var requireValue = (condition, message, status = 400) => {
  if (!condition) throw new GameError(message, status);
};
var codeOf = (value) => typeof value === "string" ? value.trim().toUpperCase() : "";
var idOf = (value) => {
  requireValue(typeof value === "string" && /^[A-Za-z0-9_-]{16,100}$/u.test(value), "Please retry this action.", 400);
  return value;
};
var success = (body) => ({ status: 200, body });
var failed = (error) => ({ status: error.status || 500, body: { error: error.message } });
function candidateCode(requestId, index) {
  const bytes = createHash2("sha256").update(`majority-rules:${requestId}:${index}`).digest();
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return [...bytes.subarray(0, 6)].map((byte) => alphabet[byte % alphabet.length]).join("");
}
function config() {
  return {
    colors: COLORS,
    themes: THEMES,
    decks: DECKS.map(({ id, title, description, questions }) => ({ id, title, description, count: questions.length })),
    deckCapacity: MAX_DECKS,
    roundOptions: [3, 5, 10, 15, 20],
    pollInterval: 1e3
  };
}
function entry(engine, room, player) {
  return { room: room.code, token: player.token, playerId: player.id, state: engine.snapshot(room, player) };
}
function signature(input, token) {
  return hash(JSON.stringify([input.op, codeOf(input.room || input.code), input.nickname, input.color, input.action, input.data, hash(token || "")]));
}
function receiptFor(room, input, token) {
  const receipt = (room.receipts || []).find((item) => item.id === input.requestId);
  if (receipt) requireValue(receipt.signature === signature(input, token), "That request has already been used. Please try again.", 409);
  return receipt;
}
function remember(room, input, token, response, playerId) {
  room.receipts ||= [];
  room.receipts.push({
    id: input.requestId,
    signature: signature(input, token),
    status: response.status,
    // Snapshots are reconstructed on a retry, so old receipts never expose stale votes.
    body: response.status === 200 ? { ok: true, result: response.body.result ?? null } : response.body,
    playerId
  });
  if (room.receipts.length > MAX_RECEIPTS) room.receipts.splice(0, room.receipts.length - MAX_RECEIPTS);
}
function rememberedResponse(engine, room, input, receipt) {
  if (receipt.status !== 200) return { status: receipt.status, body: receipt.body };
  const player = room.players.get(receipt.playerId);
  if (input.op === "join") {
    requireValue(player, "Your seat has expired. Please join again.", 401);
    return success(entry(engine, room, player));
  }
  return success({ ...receipt.body, ...player ? { state: engine.snapshot(room, player) } : {} });
}
function reconcile(engine, room, player, timestamp) {
  let visibleChange = false;
  if (player) {
    if (!player.connected) {
      player.connected = true;
      player.offlineAt = null;
      visibleChange = true;
    }
    if (timestamp - player.lastSeen >= HEARTBEAT_WRITE_MS || visibleChange) {
      player.lastSeen = timestamp;
      room.lastActivityAt = timestamp;
    }
  }
  for (const other of room.players.values()) {
    if (other.id !== player?.id && other.connected && timestamp - other.lastSeen >= OFFLINE_AFTER_MS) {
      other.connected = false;
      other.offlineAt = timestamp;
      visibleChange = true;
    }
  }
  const previousHost = room.hostId;
  engine.migrateHost(room);
  if (room.hostId !== previousHost) visibleChange = true;
  const previousBallot = room.ballot?.id;
  engine.evaluateBallot(room);
  if (room.ballot?.id !== previousBallot) visibleChange = true;
  const previousPhase = room.phase;
  if (room.phase === "voting" && timestamp >= room.round.deadline) engine.reveal(room);
  else engine.maybeReveal(room);
  if (room.phase !== previousPhase) visibleChange = true;
  if (visibleChange) engine.emit(room);
}
function createGameService({ store, now = Date.now, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)) }) {
  async function read(code) {
    const stored = await store.getWithMetadata(roomKey(code), { type: "json", consistency: "strong" });
    if (stored) {
      requireValue(typeof stored.etag === "string" && stored.etag.trim().length > 0, "The party server is busy. Please try again.", 503);
    }
    return stored;
  }
  async function pause(attempt) {
    await sleep(Math.min(60, 4 * (attempt + 1)) + randomInt2(6));
  }
  async function create(input) {
    const requestId = idOf(input.requestId);
    const createSignature = signature(input, "");
    for (let attempt = 0, index = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const code = candidateCode(requestId, index);
      const stored = await read(code);
      if (stored) {
        const room2 = decodeRoom(stored.data);
        if (room2.creationRequest === hash(requestId)) {
          requireValue(room2.creationSignature === createSignature, "That request has already been used. Please try again.", 409);
          requireValue(now() - room2.lastActivityAt < ROOM_IDLE_TTL_MS, "Room not found. Check the six-character code.", 404);
          const engine2 = new GameEngine({ now });
          const player = room2.players.get(room2.creatorId);
          requireValue(player, "Your seat has expired. Please join again.", 401);
          return success(entry(engine2, room2, player));
        }
        index++;
        continue;
      }
      const engine = new GameEngine({ now });
      const { room, p } = engine.create(input);
      room.code = code;
      room.creatorId = p.id;
      room.creationRequest = hash(requestId);
      room.creationSignature = createSignature;
      room.lastActivityAt = now();
      room.receipts = [];
      const written = await store.setJSON(roomKey(code), encodeRoom(room), { onlyIfNew: true });
      if (written.modified) return success(entry(engine, room, p));
      await pause(attempt);
    }
    throw new GameError("The party server is busy. Please try again.", 503);
  }
  async function transaction(input, token) {
    const code = codeOf(input.room || input.code);
    requireValue(/^[A-Z0-9]{6}$/u.test(code), "Room not found. Check the six-character code.", 404);
    const mutating = input.op === "join" || input.op === "action" && input.action !== "export";
    if (mutating) idOf(input.requestId);
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const stored = await read(code);
      requireValue(stored, "Room not found. Check the six-character code.", 404);
      const room = decodeRoom(stored.data);
      const timestamp = now();
      requireValue(timestamp - room.lastActivityAt < ROOM_IDLE_TTL_MS, "Room not found. Check the six-character code.", 404);
      const before = JSON.stringify(encodeRoom(room));
      const engine = new GameEngine({ now: () => timestamp });
      engine.rooms.set(code, room);
      const receipt = mutating ? receiptFor(room, input, token) : null;
      let player = null;
      if (input.op === "poll" || input.op === "action") {
        player = receipt ? room.players.get(receipt.playerId) : engine.player(room, token);
      }
      if (receipt && input.op === "join") player = room.players.get(receipt.playerId);
      reconcile(engine, room, player, timestamp);
      let response;
      try {
        if (receipt) response = rememberedResponse(engine, room, input, receipt);
        else {
          if (input.op === "lookup") response = success(engine.publicInfo(room));
          else if (input.op === "poll") response = success({ state: engine.snapshot(room, player) });
          else if (input.op === "join") {
            player = engine.join(code, input).p;
            engine.migrateHost(room);
            room.lastActivityAt = timestamp;
            response = success(entry(engine, room, player));
          } else if (input.op === "action") {
            const result = engine.action(room, player, input.action, input.data);
            room.lastActivityAt = timestamp;
            response = success({ ok: true, result: result ?? null, ...room.players.has(player.id) ? { state: engine.snapshot(room, player) } : {} });
          } else throw new GameError("Unknown action.", 404);
        }
      } catch (error) {
        if (!(error instanceof GameError)) throw error;
        response = failed(error);
      }
      if (!receipt && mutating) remember(room, input, token, response, player?.id);
      const data = encodeRoom(room);
      if (JSON.stringify(data) === before) return response;
      const written = await store.setJSON(roomKey(code), data, { onlyIfMatch: stored.etag });
      if (written.modified) return response;
      await pause(attempt);
    }
    throw new GameError("Too many requests. Give it a moment and try again.", 429);
  }
  return async function game2(input, token = "") {
    try {
      requireValue(input && typeof input === "object" && !Array.isArray(input), "Please send valid question data.");
      if (input.op === "action" && input.data !== void 0) {
        requireValue(input.data && typeof input.data === "object" && !Array.isArray(input.data), "Please send valid question data.");
      }
      if (input.op === "config") return success(config());
      if (input.op === "create") return await create(input);
      if (!["lookup", "join", "poll", "action"].includes(input.op)) throw new GameError("Unknown action.", 404);
      return await transaction(input, token);
    } catch (error) {
      if (!(error instanceof GameError)) throw error;
      return failed(error);
    }
  };
}

// netlify/functions/game.ts
var headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer"
};
var json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers });
async function game(request, _context) {
  if (request.method !== "POST") return json({ error: "Use a POST request." }, 405);
  if (request.headers.get("origin") && request.headers.get("origin") !== new URL(request.url).origin) {
    return json({ error: "Open the game on its own address to continue." }, 403);
  }
  if (!request.headers.get("content-type")?.startsWith("application/json")) return json({ error: "Expected JSON data." }, 415);
  try {
    const text = await request.text();
    if (new TextEncoder().encode(text).byteLength > 12e4) return json({ error: "That request is too large." }, 413);
    let input;
    try {
      input = JSON.parse(text);
    } catch {
      return json({ error: "Please send valid question data." }, 400);
    }
    const token = request.headers.get("authorization")?.replace(/^Bearer /u, "") || "";
    const store = getStore({ name: "majority-rules-rooms", consistency: "strong" });
    const result = await createGameService({ store })(input, token);
    return json(result.body, result.status);
  } catch (error) {
    console.error("Game request failed:", error instanceof Error ? error.message : "Unknown error");
    return json({ error: "Something went wrong. Please try again." }, 500);
  }
}
export {
  game as default
};
